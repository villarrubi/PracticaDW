<?php
require_once '../backend/conexion.php';
session_start();

// Solo acceso para promotores
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'promotor') {
    header('Location: ../USUARIO/login.html');
    exit;
}

$errores = [];
$exito = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $tipo = $_POST['tipo'] ?? '';
    $plazas = intval($_POST['plazas'] ?? 0);
    $precio = floatval($_POST['precio'] ?? 0);
    $lugar = trim($_POST['lugar'] ?? '');
    $fecha_inicio = $_POST['fecha_inicio'] ?? '';
    $fecha_fin = $_POST['fecha_fin'] ?? '';
    $id_promotor = $_SESSION['email'];

    // Validaciones
    if (!$nombre || !$tipo || !$plazas || !$lugar || !$fecha_inicio || !$fecha_fin) {
        $errores[] = "Todos los campos obligatorios deben estar completos.";
    }

    // Manejo de imagen
    $nombreImagen = null;
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === 0) {
        $ext = pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION);
        $nombreImagen = uniqid('evento_', true) . '.' . $ext;
        $rutaDestino = '../fotos/' . $nombreImagen;

        if (!move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
            $errores[] = "Error al subir la imagen.";
        }
    }

    if (empty($errores)) {
        $stmt = $pdo->prepare("INSERT INTO eventos 
            (nombre, descripcion, tipo, plazas, precio, lugar, fecha_inicio, fecha_fin, id_promotor, imagen)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $nombre, $descripcion, $tipo, $plazas, $precio, $lugar,
            $fecha_inicio, $fecha_fin, $id_promotor, $nombreImagen
        ]);
        $exito = true;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Evento</title>
    <style>
        body {
            background-color: #ffd5d5;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            padding-top: 50px;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 500px;
        }

        h2 {
            color: #d62822;
            text-align: center;
            text-decoration: underline;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input, textarea, select {
            margin-bottom: 12px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        button {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #a32839;
        }

        .mensaje {
            margin-top: 10px;
            text-align: center;
            font-weight: bold;
        }

        .exito {
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Crear Nuevo Evento</h2>

        <?php if ($exito): ?>
            <p class="mensaje exito">Evento creado correctamente</p>
        <?php elseif (!empty($errores)): ?>
            <p class="mensaje error">Fallo al crear el evento<?= implode('<br>', $errores) ?></p>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="nombre" placeholder="Nombre del evento" required>
            <textarea name="descripcion" placeholder="Descripción (opcional)"></textarea>
            <select name="tipo" required>
                <option value="">Tipo de evento</option>
                <option value="concierto">Concierto</option>
                <option value="cine">Cine</option>
                <option value="prueba deportiva">Prueba deportiva</option>
                <option value="exposición">Exposición</option>
            </select>
            <input type="number" name="plazas" placeholder="Plazas disponibles" required>
            <input type="number" step="0.01" name="precio" placeholder="Precio (€)" required>
            <input type="text" name="lugar" placeholder="Lugar del evento" required>
            <input type="date" name="fecha_inicio" required>
            <input type="date" name="fecha_fin" required>
            <input type="file" name="imagen" accept="image/*">
            <button type="submit">Crear Evento</button>
        </form>
        <form method="GET" action="promotor.php">
            <button type="submit" style="width: 100%; margin-top: 10px;">⬅ Volver al Panel</button>
        </form>
    </div>

</body>
</html>
