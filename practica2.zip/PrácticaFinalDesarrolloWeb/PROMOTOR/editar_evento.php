<?php
require_once '../backend/conexion.php';
session_start();

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'promotor') {
    header('Location: ../USUARIO/login.html');
    exit;
}

$email = $_SESSION['email'];
$id = intval($_GET['id'] ?? 0);

// Obtener evento existente
$stmt = $pdo->prepare("SELECT * FROM eventos WHERE id = ? AND id_promotor = ?");
$stmt->execute([$id, $email]);
$evento = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$evento) {
    exit("<p style='text-align:center;padding-top:50px;font-family:sans-serif;'>Evento no encontrado o no autorizado.</p>");
}

$errores = [];
$exito = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $tipo = $_POST['tipo'] ?? '';
    $plazas = intval($_POST['plazas'] ?? 0);
    $precio = floatval($_POST['precio'] ?? 0);
    $lugar = trim($_POST['lugar'] ?? '');
    $fecha_inicio = $_POST['fecha_inicio'] ?? '';
    $fecha_fin = $_POST['fecha_fin'] ?? '';

    $nombreImagen = $evento['imagen'];
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === 0) {
        $ext = pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION);
        $nombreImagen = uniqid('evento_', true) . '.' . $ext;
        $rutaDestino = '../fotos/' . $nombreImagen;
        move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino);
    }

    if (!$nombre || !$tipo || !$plazas || !$lugar || !$fecha_inicio || !$fecha_fin) {
        $errores[] = "Todos los campos obligatorios deben estar completos.";
    }

    if (empty($errores)) {
        $stmt = $pdo->prepare("UPDATE eventos SET nombre=?, descripcion=?, tipo=?, plazas=?, precio=?, lugar=?, fecha_inicio=?, fecha_fin=?, imagen=? WHERE id=? AND id_promotor=?");
        $stmt->execute([$nombre, $descripcion, $tipo, $plazas, $precio, $lugar, $fecha_inicio, $fecha_fin, $nombreImagen, $id, $email]);
        $exito = true;
        // Refrescar evento
        $evento = array_merge($evento, $_POST);
        $evento['imagen'] = $nombreImagen;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Evento</title>
    <style>
        body {
            background-color: #ffd5d5;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            padding-top: 50px;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 500px;
        }
        h2 {
            color: #d62822;
            text-align: center;
            text-decoration: underline;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input, textarea, select {
            margin-bottom: 12px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }
        button {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #a32839;
        }
        .mensaje {
            text-align: center;
            margin-bottom: 10px;
            font-weight: bold;
        }
        .exito {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Editar Evento</h2>

    <?php if ($exito): ?>
        <p class="mensaje exito">Evento actualizado correctamente.</p>
    <?php elseif (!empty($errores)): ?>
        <p class="mensaje error">Fallo al actualizar el evento<?= implode('<br>', $errores) ?></p>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="nombre" placeholder="Nombre" value="<?= htmlspecialchars($evento['nombre']) ?>" required>
        <textarea name="descripcion" placeholder="Descripción opcional"><?= htmlspecialchars($evento['descripcion']) ?></textarea>
        <select name="tipo" required>
            <option value="">Tipo de evento</option>
            <option value="concierto" <?= $evento['tipo']==='concierto' ? 'selected' : '' ?>>Concierto</option>
            <option value="cine" <?= $evento['tipo']==='cine' ? 'selected' : '' ?>>Cine</option>
            <option value="prueba deportiva" <?= $evento['tipo']==='prueba deportiva' ? 'selected' : '' ?>>Prueba deportiva</option>
            <option value="exposición" <?= $evento['tipo']==='exposición' ? 'selected' : '' ?>>Exposición</option>
        </select>
        <input type="number" name="plazas" placeholder="Plazas" value="<?= $evento['plazas'] ?>" required>
        <input type="number" step="0.01" name="precio" placeholder="Precio (€)" value="<?= $evento['precio'] ?>" required>
        <input type="text" name="lugar" placeholder="Lugar" value="<?= htmlspecialchars($evento['lugar']) ?>" required>
        <input type="date" name="fecha_inicio" value="<?= $evento['fecha_inicio'] ?>" required>
        <input type="date" name="fecha_fin" value="<?= $evento['fecha_fin'] ?>" required>
        <label>Imagen actual:</label>
        <?php if ($evento['imagen']): ?>
            <img src="../fotos/<?= htmlspecialchars($evento['imagen']) ?>" alt="Imagen actual" style="max-width:100%; margin-bottom:10px;">
        <?php endif; ?>
        <input type="file" name="imagen" accept="image/*">
        <button type="submit">Guardar Cambios</button>
    </form>
    <div style="text-align: center; margin-top: 20px;">
        <a href="gestionar_eventos.php" style="background-color: #d9534f; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold;">⬅ Volver</a>
    </div>
</div>
</body>
</html>
