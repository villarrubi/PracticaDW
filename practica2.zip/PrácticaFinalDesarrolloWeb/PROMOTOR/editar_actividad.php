<?php
require_once '../backend/conexion.php';
session_start();

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'promotor') {
    header('Location: ../USUARIO/login.html');
    exit;
}

$email = $_SESSION['email'];

// Eliminar actividad
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_eliminar'])) {
    $idEliminar = intval($_POST['id_eliminar']);
    $stmt = $pdo->prepare("DELETE FROM actividades WHERE id = ? AND id_evento IN (SELECT id FROM eventos WHERE id_promotor = ?)");
    $stmt->execute([$idEliminar, $email]);
    header("Location: gestionar_actividades.php");
    exit;
}

// Obtener actividades
$stmt = $pdo->prepare("SELECT a.*, e.nombre AS nombre_evento FROM actividades a JOIN eventos e ON a.id_evento = e.id WHERE e.id_promotor = ? ORDER BY e.fecha_inicio DESC");
$stmt->execute([$email]);
$actividades = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestionar Actividades</title>
    <style>
        body {
            background-color: #ffd5d5;
            font-family: Arial, sans-serif;
            padding: 20px;
            margin: 0;
        }
        .logout {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 999;
        }
        .logout a {
            background-color: #d9534f;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }
        .logout a:hover {
            background-color: #a32839;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            max-width: 1000px;
            margin: auto;
        }
        h2 {
            color: #d62822;
            text-align: center;
            text-decoration: underline;
            margin-bottom: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }
        a.button, button {
            background-color: #d9534f;
            color: white;
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
        }
        a.button:hover, button:hover {
            background-color: #a32839;
        }
        .volver {
            text-align: center;
            margin-top: 20px;
        }
        .volver a {
            background-color: #d9534f;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }
        .volver a:hover {
            background-color: #a32839;
        }
        .no-data {
            text-align: center;
            font-size: 18px;
            padding: 20px;
        }
    </style>
</head>
<body>
<?php if (isset($_SESSION['email'])): ?>
    <div class="logout">
        <a href="../backend/logout.php">Cerrar sesión</a>
    </div>
<?php endif; ?>

<div class="container">
    <h2>Editar / Eliminar Mis Actividades</h2>

    <?php if (count($actividades) === 0): ?>
        <p class="no-data">No tienes actividades creadas.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Nombre</th>
                <th>Evento</th>
                <th>Horario</th>
                <th>Plazas</th>
                <th>Acciones</th>
            </tr>
            <?php foreach ($actividades as $actividad): ?>
                <tr>
                    <td><?= htmlspecialchars($actividad['nombre']) ?></td>
                    <td><?= htmlspecialchars($actividad['nombre_evento']) ?></td>
                    <td><?= htmlspecialchars($actividad['hora_inicio']) ?> - <?= htmlspecialchars($actividad['hora_fin']) ?></td>
                    <td><?= $actividad['plazas'] ?></td>
                    <td>
                        <a class="button" href="editar_actividad.php?id=<?= $actividad['id'] ?>">Editar</a>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="id_eliminar" value="<?= $actividad['id'] ?>">
                            <button type="submit" onclick="return confirm('¿Seguro que deseas eliminar esta actividad?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>

    <div class="volver">
        <a href="actividades.html">⬅ Volver</a>
    </div>
</div>
</body>
</html>
