<?php
require_once '../backend/conexion.php';
session_start();

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'promotor') {
    header('Location: ../USUARIO/login.html');
    exit;
}

$email = $_SESSION['email'];

// Obtener eventos del promotor
$stmt = $pdo->prepare("SELECT * FROM eventos WHERE id_promotor = ? ORDER BY fecha_inicio ASC");
$stmt->execute([$email]);
$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener número de inscritos por evento
$inscritosPorEvento = [];
foreach ($eventos as $evento) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM inscripciones WHERE id_actividad IN (SELECT id FROM actividades WHERE id_evento = ?)");
    $stmt->execute([$evento['id']]);
    $inscritosPorEvento[$evento['id']] = $stmt->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Eventos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffd5d5;
        }
        h1 {
            text-align: center;
            color: #d62822;
            text-decoration: underline;
            margin-top: 30px;
        }
        .event {
            border: 1px solid #ccc;
            padding: 16px;
            margin: 16px auto;
            display: flex;
            align-items: center;
            background-color: #fdfafa;
            border-radius: 20px;
            font-weight: bold;
            width: 80%;
        }
        .event img {
            max-width: 300px;
            max-height: 350px;
            margin-right: 16px;
            border-radius: 12px;
        }
        .event-details {
            max-width: 600px;
        }
        .event-title {
            font-size: 1.5em;
            margin: 0;
        }
        .event-description {
            margin-top: 8px;
        }
        .event-tickets {
            font-size: 1.2em;
            color: #d9534f;
            font-weight: bold;
        }
        .volver {
            text-align: center;
            margin: 20px;
        }
        .volver a {
            background-color: #d9534f;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }
        .volver a:hover {
            background-color: #a32839;
        }
        .no-events {
            text-align: center;
            font-size: 20px;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            width: 50%;
            margin: 50px auto;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <h1>Mis Eventos</h1>

    <?php if (count($eventos) === 0): ?>
        <div class="no-events">Aún no has creado ningún evento.</div>
    <?php else: ?>
        <?php foreach ($eventos as $evento): ?>
            <?php
                $imagen = $evento['imagen'] && file_exists("../fotos/{$evento['imagen']}")
                    ? "../fotos/{$evento['imagen']}"
                    : "../fotos/default.jpg";
                $inscritos = $inscritosPorEvento[$evento['id']] ?? 0;
            ?>
            <div class="event">
                <img src="<?= htmlspecialchars($imagen) ?>" alt="Imagen del evento">
                <div class="event-details">
                    <h2 class="event-title"><?= htmlspecialchars($evento['nombre']) ?></h2>
                    <p><strong>Fechas:</strong> <?= htmlspecialchars($evento['fecha_inicio']) ?> a <?= htmlspecialchars($evento['fecha_fin']) ?></p>
                    <p><strong>Lugar:</strong> <?= htmlspecialchars($evento['lugar']) ?></p>
                    <p><strong>Tipo:</strong> <?= htmlspecialchars($evento['tipo']) ?></p>
                    <p class="event-description"><?= nl2br(htmlspecialchars($evento['descripcion'])) ?></p>
                    <p class="event-tickets">Precio: <?= number_format($evento['precio'], 2) ?> €</p>
                    <p><strong>Inscritos:</strong> <?= $inscritos ?> personas</p>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <div class="volver">
        <a href="promotor.php">⬅ Volver al Panel</a>
    </div>
</body>
</html>
