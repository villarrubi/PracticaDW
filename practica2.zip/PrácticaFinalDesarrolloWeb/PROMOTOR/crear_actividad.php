<?php
require_once '../backend/conexion.php';
session_start();

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'promotor') {
    header('Location: ../USUARIO/login.html');
    exit;
}

$email = $_SESSION['email'];

// Obtener eventos del promotor para asignar actividad
$stmt = $pdo->prepare("SELECT id, nombre, plazas FROM eventos WHERE id_promotor = ? ORDER BY fecha_inicio DESC");
$stmt->execute([$email]);
$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$errores = [];
$exito = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_evento = intval($_POST['id_evento'] ?? 0);
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $hora_inicio = $_POST['hora_inicio'] ?? null;
    $hora_fin = $_POST['hora_fin'] ?? null;

    // Obtener plazas del evento seleccionado
    $plazas = 0;
    foreach ($eventos as $ev) {
        if ($ev['id'] == $id_evento) {
            $plazas = $ev['plazas'];
            break;
        }
    }

    if (!$id_evento || !$nombre || !$hora_inicio || !$hora_fin || !$plazas) {
        $errores[] = "Todos los campos obligatorios deben estar completos.";
    }

    if (empty($errores)) {
        $stmt = $pdo->prepare("INSERT INTO actividades (id_evento, nombre, descripcion, hora_inicio, hora_fin, plazas)
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$id_evento, $nombre, $descripcion, $hora_inicio, $hora_fin, $plazas]);
        $exito = true;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Actividad</title>
    <style>
        body {
            background-color: #ffd5d5;
            font-family: Arial, sans-serif;
            margin: 0;
            padding-top: 80px;
        }
        .logout {
            position: fixed;
            top: 20px;
            right: 20px;
        }
        .logout a {
            background-color: #d9534f;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }
        .logout a:hover {
            background-color: #a32839;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 500px;
            margin: auto;
        }
        h2 {
            color: #d62822;
            text-align: center;
            text-decoration: underline;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input, textarea, select {
            margin-bottom: 12px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }
        button {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #a32839;
        }
        .mensaje {
            text-align: center;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .exito {
            color: green;
        }
        .error {
            color: red;
        }
        .volver {
            text-align: center;
            margin-top: 20px;
        }
        .volver a {
            background-color: #d9534f;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
        .volver a:hover {
            background-color: #a32839;
        }
    </style>
</head>
<body>
<?php if (isset($_SESSION['email'])): ?>
    <div class="logout">
        <a href="../backend/logout.php">Cerrar sesión</a>
    </div>
<?php endif; ?>

<div class="container">
    <h2>Crear Nueva Actividad</h2>

    <?php if ($exito): ?>
        <p class="mensaje exito"> Actividad creada correctamente.</p>
    <?php elseif (!empty($errores)): ?>
        <p class="mensaje error"> Fallo al crearla actividad. <?= implode('<br>', $errores) ?></p>
    <?php endif; ?>

    <form method="POST">
        <select name="id_evento" required>
            <option value="">Selecciona el evento</option>
            <?php foreach ($eventos as $evento): ?>
                <option value="<?= $evento['id'] ?>"><?= htmlspecialchars($evento['nombre']) ?></option>
            <?php endforeach; ?>
        </select>
        <input type="text" name="nombre" placeholder="Nombre de la actividad" required>
        <textarea name="descripcion" placeholder="Descripción (opcional)"></textarea>
        <input type="time" name="hora_inicio" required>
        <input type="time" name="hora_fin" required>
        <button type="submit">Crear Actividad</button>
    </form>

    <div class="volver">
        <a href="actividades.html">⬅ Volver a Actividades</a>
    </div>
</div>
</body>
</html>
