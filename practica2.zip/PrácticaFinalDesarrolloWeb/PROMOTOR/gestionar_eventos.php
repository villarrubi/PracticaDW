<?php
require_once '../backend/conexion.php';
session_start();

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'promotor') {
    header('Location: ../USUARIO/login.html');
    exit;
}

$email = $_SESSION['email'];

// Eliminar evento si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_eliminar'])) {
    $idEliminar = intval($_POST['id_eliminar']);
    $stmt = $pdo->prepare("DELETE FROM eventos WHERE id = ? AND id_promotor = ?");
    $stmt->execute([$idEliminar, $email]);
    header("Location: gestionar_eventos.php");
    exit;
}

// Obtener eventos del promotor
$stmt = $pdo->prepare("SELECT * FROM eventos WHERE id_promotor = ? ORDER BY fecha_inicio DESC");
$stmt->execute([$email]);
$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestionar Eventos</title>
    <style>
        body {
            background-color: #ffd5d5;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            max-width: 1000px;
            margin: auto;
        }

        h2 {
            color: #d62822;
            text-align: center;
            text-decoration: underline;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        a.button, button {
            background-color: #d9534f;
            color: white;
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
        }

        a.button:hover, button:hover {
            background-color: #a32839;
        }

        .volver {
            text-align: center;
            margin-top: 20px;
        }

        .volver a {
            background-color: #d9534f;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }

        .volver a:hover {
            background-color: #a32839;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Editar / Eliminar Mis Eventos</h2>

        <?php if (count($eventos) === 0): ?>
            <p style="text-align:center;">No has creado ningún evento aún.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Fecha</th>
                    <th>Lugar</th>
                    <th>Acciones</th>
                </tr>
                <?php foreach ($eventos as $evento): ?>
                    <tr>
                        <td><?= htmlspecialchars($evento['nombre']) ?></td>
                        <td><?= htmlspecialchars($evento['tipo']) ?></td>
                        <td><?= htmlspecialchars($evento['fecha_inicio']) ?> → <?= htmlspecialchars($evento['fecha_fin']) ?></td>
                        <td><?= htmlspecialchars($evento['lugar']) ?></td>
                        <td>
                            <a class="button" href="editar_evento.php?id=<?= $evento['id'] ?>">Editar</a>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="id_eliminar" value="<?= $evento['id'] ?>">
                                <button type="submit" onclick="return confirm('¿Seguro que deseas eliminar este evento?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <div class="volver">
            <a href="promotor.php">⬅ Volver al Panel</a>
        </div>
    </div>
</body>
</html>
