<?php
require_once 'conexion.php';
session_start();

if (!isset($_SESSION['email'])) {
    exit('Sesión no válida. Inicia sesión primero.');
}

$email = $_SESSION['email'];

// Solicitar ser promotor"
if (isset($_POST['solicitar_promotor'])) {
    $stmt = $pdo->prepare("SELECT * FROM solicitudes_promotor WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->rowCount() === 0) {
        $insertar = $pdo->prepare("INSERT INTO solicitudes_promotor (email) VALUES (?)");
        $insertar->execute([$email]);
    }
    header('Location: ../USUARIO/perfil.php?solicitud=ok');
    exit;
}

//Datos forumlario
$datos = [
    'nombre' => trim($_POST['nombre'] ?? ''),
    'apellidos' => trim($_POST['apellidos'] ?? ''),
    'telefono' => trim($_POST['telefono'] ?? ''),
    'direccion' => trim($_POST['direccion'] ?? ''),
    'localidad' => trim($_POST['localidad'] ?? ''),
    'cp' => trim($_POST['cp'] ?? ''),
    'tarjeta' => trim($_POST['tarjeta'] ?? ''),
    'caducidad' => trim($_POST['caducidad'] ?? ''),
    'ccv' => trim($_POST['ccv'] ?? '')
];

// Actualizar db
$stmt = $pdo->prepare("UPDATE usuarios SET 
    nombre = :nombre,
    apellidos = :apellidos,
    telefono = :telefono,
    direccion = :direccion,
    localidad = :localidad,
    cp = :cp,
    tarjeta = :tarjeta,
    caducidad = :caducidad,
    ccv = :ccv
    WHERE email = :email");

$datos['email'] = $email;
$stmt->execute($datos);

header('Location: ../USUARIO/perfil.php');
exit;
