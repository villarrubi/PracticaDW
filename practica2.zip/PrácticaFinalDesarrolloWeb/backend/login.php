<?php
require_once 'conexion.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        exit('Debe completar todos los campos.');
    }

    // Buscar usuario por email
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        header('Location: ../USUARIO/error_usuario.html');
        exit;
    }

    if (!password_verify($password, $usuario['password'])) {
        header('Location: ../USUARIO/error_login.html');
        exit;
    }

    // Login correcto: guardar sesión
    $_SESSION['email'] = $usuario['email'];
    $_SESSION['rol'] = $usuario['rol'];

    // Redirigir al catalogo
    header('Location: ../USUARIO/catalogo.php');
    exit;
} else {
    echo 'Acceso no permitido.';
}
