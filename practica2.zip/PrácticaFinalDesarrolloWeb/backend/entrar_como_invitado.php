<?php
session_start();
$_SESSION['rol'] = 'invitado';
header('Location: ../USUARIO/catalogo.php');
exit;
