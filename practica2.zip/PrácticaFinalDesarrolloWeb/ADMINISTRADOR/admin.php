<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['rol'] !== 'administrador') {
    header('Location: ../USUARIO/login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Administrador</title>
    <style>
        body {
            background-color: #ffd5d5;
            font-family: Arial, sans-serif;
            margin: 0;
            padding-top: 80px;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            width: 400px;
            margin: auto;
            text-align: center;
        }
        h2 {
            color: #d62822;
            text-decoration: underline;
        }
        button {
            display: block;
            width: 80%;
            margin: 10px auto;
            padding: 10px 20px;
            background-color: #d9534f;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #a32839;
        }
        .top-right {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 999;
        }
        .top-right a {
            background-color: #d9534f;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .top-right a:hover {
            background-color: #a32839;
        }
    </style>
</head>
<body>
<div class="top-right">
    <a href="../backend/logout.php">Cerrar sesión</a>
</div>
<div class="container">
    <h2>Panel del Administrador</h2>
    <button onclick="location.href='altaPromotor.html'">Alta de Promotores</button>
    <button onclick="location.href='cambiarRol.php'">Cambiar Roles</button>
    <button onclick="location.href='solicitudes.php'">Ver Solicitudes de Promotor</button>
</div>

<div style="text-align: center; margin: 40px auto;">
    <a href="../USUARIO/catalogo.php" style="background-color: #d9534f; color: white; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: bold; box-shadow: 0 2px 4px rgba(0,0,0,0.2); transition: background-color 0.3s ease;">
        ⬅ Volver al Catálogo
    </a>
</div>
</body>
</html>
