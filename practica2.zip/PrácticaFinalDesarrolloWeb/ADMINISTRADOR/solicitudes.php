<?php
require_once '../backend/conexion.php';
session_start();

if (!isset($_SESSION['email']) || $_SESSION['rol'] !== 'administrador') {
    header('Location: ../USUARIO/login.html');
    exit;
}

// Aceptar o rechazar solicitud
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['aceptar'])) {
        $email = $_POST['aceptar'];
        $pdo->prepare("UPDATE usuarios SET rol = 'promotor' WHERE email = ?")->execute([$email]);
        $pdo->prepare("UPDATE solicitudes_promotor SET estado = 'aceptado' WHERE email = ?")->execute([$email]);
    } elseif (isset($_POST['rechazar'])) {
        $email = $_POST['rechazar'];
        $pdo->prepare("UPDATE solicitudes_promotor SET estado = 'rechazado' WHERE email = ?")->execute([$email]);
    }
}

// Obtener solicitudes pendientes
$stmt = $pdo->query("SELECT s.email, u.nombre, u.apellidos 
                     FROM solicitudes_promotor s 
                     JOIN usuarios u ON s.email = u.email 
                     WHERE s.estado = 'pendiente'");
$solicitudes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Solicitudes de Promotor</title>
    <style>
        body {
            background-color: #ffd5d5;
            font-family: Arial, sans-serif;
            padding: 40px;
        }

        .solicitud {
            background-color: white;
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 10px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }

        .email {
            font-weight: bold;
            color: #a32839;
        }

        form {
            display: inline;
        }

        button {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
            margin-left: 10px;
        }

        button:hover {
            background-color: #a32839;
        }

        h2 {
            text-align: center;
            color: #d62822;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <h2>Solicitudes de Promotor Pendientes</h2>

    <?php if (count($solicitudes) > 0): ?>
        <?php foreach ($solicitudes as $solicitud): ?>
            <div class="solicitud">
                <p><span class="email"><?= htmlspecialchars($solicitud['email']) ?></span></p>
                <p><?= htmlspecialchars($solicitud['nombre']) ?> <?= htmlspecialchars($solicitud['apellidos']) ?></p>
                <form method="POST">
                    <button type="submit" name="aceptar" value="<?= htmlspecialchars($solicitud['email']) ?>">Aceptar</button>
                </form>
                <form method="POST">
                    <button type="submit" name="rechazar" value="<?= htmlspecialchars($solicitud['email']) ?>">Rechazar</button>
                </form>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="text-align:center;">No hay solicitudes pendientes.</p>
    <?php endif; ?>

    <div style="text-align: center; margin-top: 20px;">
            <a href="admin.php" style="background-color: #d9534f; color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: bold; display: inline-block;">
                ⬅ Volver al control
            </a>
        </div>
</body>
</html>
