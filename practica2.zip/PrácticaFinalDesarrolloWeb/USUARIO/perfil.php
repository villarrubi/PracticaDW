<?php
require_once '../backend/conexion.php';
session_start();

if (!isset($_SESSION['email'])) {
    header('Location: login.html');
    exit;
}

$email = $_SESSION['email'];

// Obtener datos del usuario actual
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
$stmt->execute([$email]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    exit("Usuario no encontrado.");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Perfil de Usuario</title>
    <style>
        body {
            background-color: #ffd5d5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-family: Arial, sans-serif;
            margin: 0;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.15);
            width: 450px;
        }

        h2 {
            color: #d62822;
            text-align: center;
            text-decoration: underline;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input {
            padding: 10px;
            margin-bottom: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        button {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #a32839;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Editar Perfil</h2>
        <form action="../backend/editar_perfil.php" method="POST">
            <input type="text" name="nombre" placeholder="Nombre" value="<?= htmlspecialchars($usuario['nombre']) ?>" required>
            <input type="text" name="apellidos" placeholder="Apellidos" value="<?= htmlspecialchars($usuario['apellidos']) ?>" required>
            <input type="text" name="telefono" placeholder="Teléfono" value="<?= htmlspecialchars($usuario['telefono'] ?? '') ?>">
            <input type="text" name="direccion" placeholder="Dirección" value="<?= htmlspecialchars($usuario['direccion'] ?? '') ?>">
            <input type="text" name="localidad" placeholder="Localidad" value="<?= htmlspecialchars($usuario['localidad'] ?? '') ?>">
            <input type="text" name="cp" placeholder="Código Postal" value="<?= htmlspecialchars($usuario['cp'] ?? '') ?>">
            <input type="text" name="tarjeta" placeholder="Nº Tarjeta" value="<?= htmlspecialchars($usuario['tarjeta'] ?? '') ?>">
            <input type="month" name="caducidad" placeholder="Fecha Caducidad" value="<?= htmlspecialchars($usuario['caducidad'] ?? '') ?>">
            <input type="text" name="ccv" placeholder="CCV" value="<?= htmlspecialchars($usuario['ccv'] ?? '') ?>">
            <button type="submit">Guardar Cambios</button>
        </form>
        <hr>
        <form action="../backend/editar_perfil.php" method="POST">
            <button type="submit" name="solicitar_promotor">Solicitar ser promotor</button>
        </form>


        <?php if (isset($mensaje)): ?>
            <div class="mensaje"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <div style="text-align: center; margin-top: 20px;">
            <a href="catalogo.php" style="background-color: #d9534f; color: white; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: bold; display: inline-block;">
                ⬅ Volver al Catálogo
            </a>
        </div>
    </div>
</body>
</html>
