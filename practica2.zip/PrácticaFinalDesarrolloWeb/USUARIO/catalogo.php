<?php
require_once '../backend/conexion.php';
session_start();
$rol = $_SESSION['rol'] ?? 'invitado';

$stmt = $pdo->query("SELECT * FROM eventos ORDER BY fecha_inicio ASC");
$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Catálogo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffd5d5;
        }

        .perfil-btn, .login-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #d9534f;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
        }

        .perfil-btn:hover, .login-btn:hover {
            background-color: #a32839;
        }

        h1 {
            text-align: center;
            color: #d62822;
            text-decoration: underline;
        }

        .event {
            border: 1px solid #ccc;
            padding: 16px;
            margin: 16px auto;
            display: flex;
            align-items: center;
            background-color: #fdfafa;
            border-radius: 20px;
            font-weight: bold;
            position: relative;
            width: 80%;
        }

        .event img {
            max-width: 300px;
            max-height: 350px;
            margin-right: 16px;
            border-radius: 12px;
        }

        .event-details {
            max-width: 600px;
        }

        .event-title {
            font-size: 1.5em;
            margin: 0;
        }

        .event-description {
            margin-top: 8px;
        }

        .event-tickets {
            font-size: 1.2em;
            color: #d9534f;
            font-weight: bold;
        }

        a {
            text-decoration: none;
            color: #1498a4;
            cursor: pointer;
        }

        .no-events {
            text-align: center;
            font-size: 20px;
            margin-top: 50px;
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            width: 50%;
            margin-left: auto;
            margin-right: auto;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .top-right {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 999;
            display: flex;
            gap: 10px;
        }
        .top-right a {
            background-color: #d9534f;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            transition: background-color 0.3s ease;
        }
        .top-right a:hover {
            background-color: #a32839;
        }
    </style>
</head>
<body>

    <div class="top-right">
    <?php if (isset($_SESSION['email']) && $rol !== 'invitado'): ?>
        <a href="perfil.php">Editar perfil</a>
        <a href="../backend/logout.php">Cerrar sesión</a>
    <?php if ($rol === 'promotor'): ?>
        <a href="../PROMOTOR/promotor.php">Área privada</a>
    <?php elseif ($rol === 'administrador'): ?>
        <a href="../ADMINISTRADOR/admin.php">Área privada</a>
    <?php endif; ?>

    <?php elseif ($rol === 'invitado'): ?>
        <a href="../USUARIO/login.html">Iniciar sesión</a>
    <?php endif; ?>
    </div>

    <h1>Próximos eventos</h1>

    <?php if (count($eventos) === 0): ?>
        <div class="no-events">No hay eventos disponibles en este momento.</div>
    <?php else: ?>
        <?php foreach ($eventos as $evento): ?>
            <?php
                $imagen = $evento['imagen'];
                if ($imagen && file_exists("../fotos/$imagen")) {
                    $rutaImagen = "../fotos/" . $imagen;
                } else {
                    $rutaImagen = "../fotos/default.jpg";
                }
            ?>
            <div class="event">
                <img src="<?= htmlspecialchars($rutaImagen) ?>" alt="Imagen del evento">

                <div class="event-details">
                    <h2 class="event-title"><?= htmlspecialchars($evento['nombre']) ?></h2>
                    <p><strong>Fecha:</strong> <?= htmlspecialchars($evento['fecha_inicio']) ?> a <?= htmlspecialchars($evento['fecha_fin']) ?></p>
                    <p><strong>Lugar:</strong> <?= htmlspecialchars($evento['lugar']) ?></p>
                    <p><strong>Tipo:</strong> <?= htmlspecialchars($evento['tipo']) ?></p>
                    <p class="event-description"><?= nl2br(htmlspecialchars($evento['descripcion'] ?? '')) ?></p>
                    <p class="event-tickets">Precio: <?= number_format($evento['precio'], 2) ?> €</p>

                    <?php if ($rol !== 'invitado'): ?>
                        <a href="alertas.html">INSCRIBIRSE</a> |
                        <a href="contacto.html">Contactar con el promotor</a> |
                    <?php endif; ?>
                    <a href="compartir.html">Compartir</a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
</body>
</html>
