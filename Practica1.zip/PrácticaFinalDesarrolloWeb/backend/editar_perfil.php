<?php
session_start();

$archivo = __DIR__ . '/../usuarios.json';

// Verifica que haya sesión activa con email
if (!isset($_SESSION['email'])) {
    exit('Sesión no válida. Debe iniciar sesión.');
}

$email = $_SESSION['email'];

// Recoger datos del formulario
$nuevosDatos = [
    'nombre' => trim($_POST['nombre'] ?? ''),
    'apellidos' => trim($_POST['apellidos'] ?? ''),
    'telefono' => trim($_POST['telefono'] ?? ''),
    'direccion' => trim($_POST['direccion'] ?? ''),
    'localidad' => trim($_POST['localidad'] ?? ''),
    'cp' => trim($_POST['cp'] ?? ''),
    'tarjeta' => trim($_POST['tarjeta'] ?? ''),
    'caducidad' => trim($_POST['caducidad'] ?? ''),
    'ccv' => trim($_POST['ccv'] ?? '')
];

// Leer usuarios
$usuarios = file_exists($archivo) ? json_decode(file_get_contents($archivo), true) : [];
$usuarioActualizado = false;

foreach ($usuarios as &$usuario) {
    if ($usuario['email'] === $email) {
        foreach ($nuevosDatos as $clave => $valor) {
            $usuario[$clave] = $valor;
        }
        $usuarioActualizado = true;
        break;
    }
}

if ($usuarioActualizado) {
    file_put_contents($archivo, json_encode($usuarios, JSON_PRETTY_PRINT));
    header('Location: ../USUARIO/catalogo.php');
    exit;
} else {
    echo "<p>❌ No se encontró el usuario.</p>";
}


?>
