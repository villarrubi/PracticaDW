<?php
$archivo = __DIR__ . '/../usuarios.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['register-password'] ?? '';
    $repetirPassword = $_POST['register-repeat-password'] ?? '';
    $dni = trim($_POST['register-dni'] ?? '');

    if (!$nombre || !$apellidos || !$email || !$password || !$repetirPassword || !$dni) {
        exit('Todos los campos son obligatorios.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        exit('Email no válido.');
    }

    if (!preg_match('/^\d{8}[A-Z]$/', $dni)) {
        exit('DNI no válido.');
    }

    if ($password !== $repetirPassword) {
        exit('Las contraseñas no coinciden.');
    }

    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{7,}$/', $password)) {
        exit('La contraseña debe tener al menos 7 caracteres, una mayúscula, una minúscula y un número.');
    }

    $usuarios = file_exists($archivo) ? json_decode(file_get_contents($archivo), true) : [];

    foreach ($usuarios as $usuario) {
        if ($usuario['email'] === $email) {
            exit('El email ya está registrado.');
        }
    }

    $nuevoUsuario = [
        'nombre' => $nombre,
        'apellidos' => $apellidos,
        'email' => $email,
        'password' => password_hash($password, PASSWORD_DEFAULT),
        'dni' => $dni,
        'rol' => 'cliente'
    ];

    $usuarios[] = $nuevoUsuario;
    file_put_contents($archivo, json_encode($usuarios, JSON_PRETTY_PRINT));
    ?>
    
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Registro Exitoso</title>
        <style>
            body {
                background-color: #ffd5d5;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                font-family: Arial, sans-serif;
                margin: 0;
            }

            .container {
                background-color: white;
                padding: 40px;
                border-radius: 12px;
                box-shadow: 0 0 15px rgba(0,0,0,0.15);
                text-align: center;
                width: 400px;
            }

            h1 {
                color: #d62822;
                margin-bottom: 20px;
            }

            p {
                font-size: 18px;
                margin-bottom: 20px;
            }

            a {
                display: inline-block;
                background-color: #d9534f;
                color: white;
                padding: 10px 20px;
                border-radius: 5px;
                text-decoration: none;
                font-weight: bold;
                transition: background-color 0.3s ease;
            }

            a:hover {
                background-color: #a32839;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>¡Registro exitoso!</h1>
            <p>Bienvenido, <?= htmlspecialchars($nombre) ?>. Ya puedes iniciar sesión.</p>
            <a href="../USUARIO/login.html">Volver al Login</a>
        </div>
    </body>
    </html>

    <?php
    exit;
} else {
    echo 'Acceso no permitido.';
}
?>
