<?php
session_start();

$archivo = __DIR__ . '/../usuarios.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        exit('Debe completar todos los campos.');
    }

    if (!file_exists($archivo)) {
        exit('No se ha encontrado la base de datos de usuarios.');
    }

    $usuarios = json_decode(file_get_contents($archivo), true);

    foreach ($usuarios as $usuario) {
        if ($usuario['email'] === $email && password_verify($password, $usuario['password'])) {
            $_SESSION['rol'] = $usuario['rol']; // ← Guardar el rol en la sesión
            $_SESSION['email'] = $usuario['email'];

            // Redirigir según el rol
            switch ($usuario['rol']) {
                case 'cliente':
                    header('Location: ../USUARIO/catalogo.php');
                    exit;
                case 'promotor':
                    header('Location: ../PROMOTOR/promotor.html');
                    exit;
                case 'administrador':
                    header('Location: ../ADMINISTRADOR/admin.html');
                    exit;
                default:
                    exit('Rol desconocido.');
            }
        }
    }

    exit('Credenciales incorrectas.');
} else {
    echo 'Acceso no permitido.';
}
