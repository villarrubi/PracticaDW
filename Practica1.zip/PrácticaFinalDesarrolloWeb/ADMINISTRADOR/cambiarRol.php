<?php
session_start();

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'administrador') {
    header('Location: ../USUARIO/login.html');
    exit;
}

$archivo = __DIR__ . '/../usuarios.json';
$usuarios = file_exists($archivo) ? json_decode(file_get_contents($archivo), true) : [];

// Cambio de rol
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['nuevo_rol'])) {
    $email = $_POST['email'];
    $nuevoRol = $_POST['nuevo_rol'];

    foreach ($usuarios as &$usuario) {
        if ($usuario['email'] === $email) {
            $usuario['rol'] = $nuevoRol;
            break;
        }
    }

    file_put_contents($archivo, json_encode($usuarios, JSON_PRETTY_PRINT));
    header('Location: cambiarRol.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Roles</title>
    <style>
        body {
            background-color: #ffd5d5;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h1 {
            color: #d62822;
            text-align: center;
            text-decoration: underline;
        }

        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        form {
            display: inline;
        }

        button {
            padding: 6px 12px;
            background-color: #d9534f;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #a32839;
        }
    </style>
</head>
<body>
    <h1>Gestión de Roles</h1>
    <table>
        <tr>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>Email</th>
            <th>Rol Actual</th>
            <th>Acción</th>
        </tr>
        <?php foreach ($usuarios as $usuario): ?>
            <?php if ($usuario['rol'] === 'cliente' || $usuario['rol'] === 'promotor'): ?>
                <tr>
                    <td><?= htmlspecialchars($usuario['nombre']) ?></td>
                    <td><?= htmlspecialchars($usuario['apellidos']) ?></td>
                    <td><?= htmlspecialchars($usuario['email']) ?></td>
                    <td><?= htmlspecialchars($usuario['rol']) ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="email" value="<?= htmlspecialchars($usuario['email']) ?>">
                            <input type="hidden" name="nuevo_rol" value="<?= $usuario['rol'] === 'cliente' ? 'promotor' : 'cliente' ?>">
                            <button type="submit">
                                <?= $usuario['rol'] === 'cliente' ? 'Hacer Promotor' : 'Hacer Cliente' ?>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; ?>
    </table>
            <div style="text-align: center; margin: 20px;">
        <a href="admin.html" style="background-color: #d9534f; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold;">
            ⬅ Volver al Panel de Administrador
        </a>
    </div>
</body>
</html>
