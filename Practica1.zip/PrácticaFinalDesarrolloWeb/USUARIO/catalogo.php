<?php
session_start();
$rol = $_SESSION['rol'] ?? 'invitado';

// Redirección automática si el rol no es cliente ni invitado
if ($rol === 'administrador') {
    header('Location: ../ADMINISTRADOR/admin.html');
    exit;
} elseif ($rol === 'promotor') {
    header('Location: ../PROMOTOR/promotor.html');
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffd5d5;
        }

        .event {
            border: 1px solid #ccc;
            padding: 16px;
            margin: 16px 0;
            display: flex;
            align-items: center;
            background-color: #fdfafa;
            border-radius: 20px;
            font-weight: bold;
            position: relative;
        }

        .event img {
            max-width: 300px;
            max-height: 350px;
            margin-right: 16px;
        }

        .event-details {
            max-width: 600px;
        }

        .event-title {
            font-size: 1.5em;
            margin: 0;
        }

        h2 {
            color: #d62822;
            text-decoration: underline;
        }

        a {
            text-decoration: none;
            color: #1498a4;
            cursor: pointer;
        }

        .event-description {
            margin-top: 8px;
        }

        .event-tickets {
            font-size: 1.2em;
            color: #d9534f;
            font-weight: bold;
        }

        .delete-button {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #d9534f;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 12px;
            cursor: pointer;
            padding: 5px 10px;
        }

        .delete-button:hover {
            background-color: #a32839;
        }
        .perfil-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #d9534f;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
        }

        .perfil-btn:hover {
            background-color: #a32839;
        }
        .perfil-btn, .login-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #d9534f;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: background-color 0.3s ease;
        }
        .perfil-btn:hover, .login-btn:hover {
            background-color: #a32839;
        }


    </style>
</head>

<body>
    <?php if ($rol === 'cliente'): ?>
        <a href="perfil.php" class="perfil-btn">Editar Perfil</a>
    <?php else: ?>
        <a href="login.html" class="login-btn">Iniciar Sesión</a>
    <?php endif; ?>


    <h1>Próximos eventos</h1>
    <div class="event" id="event-1">
        <img src="fotos/rock.jpeg">
        <div class="event-details">
            <h2 class="event-title">Concierto de Rock</h2>
            <p class="event-date">Fecha: 15 de Octubre</p>
            <p class="event-artist">Artistas: Banda A, Banda B</p>
            <p class="event-location">Lugar: Auditorio Nacional</p>
            <p class="event-type">Tipo: Concierto</p>
            <p class="event-description">Disfruta de una noche de rock con las mejores bandas locales.</p>
            <p>Promotor: Jose Luis Sánchez</p>
            <p class="event-tickets">Tickets vendidos: 500 / 1000</p>
            <?php if ($rol !== 'invitado'): ?>
                <a href="alertas.html">INSCRIBIRSE</a> |
                <a href="contacto.html">Contactar con el promotor</a> |
            <?php endif; ?>
            <a href="compartir.html">Compartir</a>

        </div>
    </div>
    <div class="event" id="event-2">
        <img src="fotos/bambi.jpg">
        <div class="event-details">
            <h2 class="event-title">Estreno de Película</h2>
            <p class="event-date">Fecha: 20 de Octubre</p>
            <p class="event-movie">Película: Título de la Película</p>
            <p class="event-location">Lugar: Cinepolis Centro</p>
            <p class="event-type">Tipo: Cine</p>
            <p class="event-description">Ven a ver el estreno de la película más esperada del año.</p>
            <p>Promotor: Juliana Rojo López</p>
            <p class="event-tickets">Tickets vendidos: 300 / 500</p>
            <?php if ($rol !== 'invitado'): ?>
                <a href="alertas.html">INSCRIBIRSE</a> |
                <a href="contacto.html">Contactar con el promotor</a> |
            <?php endif; ?>
            <a href="compartir.html">Compartir</a>
        </div>
    </div>
    <div class="event" id="event-3">
        <img src="fotos/maraton.jpg">
        <div class="event-details">
            <h2 class="event-title">Maratón Anual</h2>
            <p class="event-date">Fecha: 25 de Octubre</p>
            <p class="event-athlete">Deportistas destacados: Atleta A, Atleta B</p>
            <p class="event-location">Lugar: Parque Central</p>
            <p class="event-type">Tipo: Prueba Deportiva</p>
            <p class="event-description">Participa en nuestro maratón anual y pon a prueba tu resistencia.</p>
            <p>Promotor: Pepe Torre de los Molinos</p>
            <p class="event-tickets">Tickets vendidos: 200 / 300</p>
            <?php if ($rol !== 'invitado'): ?>
                <a href="alertas.html">INSCRIBIRSE</a> |
                <a href="contacto.html">Contactar con el promotor</a> |
            <?php endif; ?>
            <a href="compartir.html">Compartir</a>
        </div>
    </div>
</body>

</html>